package vn.vvinh.be.enums;

public enum Gender {
    MALE,
    FEMALE
}
