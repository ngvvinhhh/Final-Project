package vn.vvinh.be.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoginRequestDTO {
    String userName;
    String password;

}
