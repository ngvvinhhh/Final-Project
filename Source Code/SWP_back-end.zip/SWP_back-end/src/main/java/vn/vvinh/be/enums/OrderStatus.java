package vn.vvinh.be.enums;

public enum OrderStatus {
    PAID,
    ORDERED,

    ACCEPT,

    REFUSE,

    FINISH


}
