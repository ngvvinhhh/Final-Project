package vn.vvinh.be.enums;

public enum Category {
    FOOD,
    DRINK,
    GAME
}
