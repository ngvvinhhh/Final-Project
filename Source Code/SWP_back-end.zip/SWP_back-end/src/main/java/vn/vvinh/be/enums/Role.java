package vn.vvinh.be.enums;

public enum Role {
    CUSTOMER,
    HOST,
    ADMIN,
}
