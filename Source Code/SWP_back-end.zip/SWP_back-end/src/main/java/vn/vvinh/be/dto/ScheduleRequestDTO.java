package vn.vvinh.be.dto;

import lombok.Getter;
import lombok.Setter;

import java.sql.Time;
@Getter
@Setter
public class ScheduleRequestDTO {
    Time time;
}
